## Omni Layer Node.js RPC client API Documentation

For more information see:

* The [OmniClientJS Github project](https://github.com/OmniLayer/OmniClientJS)
* The [Omni Core JSON-RPC API](https://github.com/OmniLayer/omnicore/blob/omnicore-0.0.10/src/omnicore/doc/rpc-api.md) documentation.


